<?php
$conn=mysqli_connect("localhost", "webterror");
$database="form";
$table_name="aset";
mysqli_select_db($conn, $database);
$sql="INSERT INTO $table_name
VALUES ('$_POST[name]', '$_POST[lastname]',
'$_POST[email]', '$_POST[phone], '$_POST[password]')";
if (!mysqli_query($conn, $sql))
{
die('Error:'.mysql_error());
}
echo "1 record added";
?>