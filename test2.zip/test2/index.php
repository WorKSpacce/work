<?php include('server.php') ?>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="style.css">
  <title>Smart Home - вход или регистрация</title>
</head>

<body>
  <form class="form" method="post" action="server.php">
    <div class="form__field">
      <input type="text" name="name" placeholder="First Name*" pattern="^[a-zA-Z]+$" required />
      <span class="form__error">Enter your first name. English keyboard layout only</span>
    </div>
    <div class="form__field">
      <input type="text" name="lastname" placeholder="Last Name*" pattern="^[a-zA-Z]+$" required />
      <span class="form__error">Enter your last name. English keyboard layout only</span>
    </div>
    <div class="form__field">
      <input type="email" name="email" placeholder="E-Mail" required />
      <span class="form__error">This field should contain an E-Mail in the format example@mail.com</span>
    </div>
    <div class="form__field">
      <select id="country" class="form-control">
      <option value="ua">Украина +380</option>
      <option value="us">США +1</option>
      <option value="kz">Казахстан +77</option>
      <option value="uz">Узбекистан +998</option>
      <option value="bg">Болгария +359</option>
      <option value="md">Молдова +373</option>
      <option value="pl">Польша +48</option>
      <option value="sk">Словакия +421</option>
      <option value="az">Азербайджан +994</option>
      <option value="by">Беларусь +375</option>
      <option value="cz">Чешская республика +420</option>
      <option value="ro">Румыния +40</option>
      <option value="ge">Грузия +995</option>
      <option value="mx">Мексика +52</option>
      <option value="kh">Камбоджа +855</option>
      <option value="br">Бразилия +55</option>
      <option value="ch">Швейцария +41</option>
      </select>
      <input id="phone" name="phone" type="text" class="phone" placeholder="Enter your phone number" required />
    </div>
    <div class="form__field">
      <input type="password" name="password" placeholder="Enter password" id="password" minlength="8" maxlength="16" onkeyup="checkPass()" />
      <span class="form__error">The password cannot be shorter than 8 or more than 16 characters. English keyboard layout only</span>
    </div>
    <div class="form__field">
      <input type="password" name="password2" placeholder="Repeat password" id="password2" maxlength="16" onkeyup="checkPass()" />
      <span id="confirmMessage" class="confirmMessage"></span>
    </div>
    <button type="submit">Send</button>
        <p>
      Already a member? <a href="login.php">Sign in</a>
    </p>
   <script>
      // password
      function checkPass() {
        var get_elem = document.getElementById,
          pass1 = document.getElementById('password'),
          pass2 = document.getElementById('password2'),
          message = document.getElementById('confirmMessage'),
          colors = {
            goodColor: "#fff",
            goodColored: "#087a08",
            badColor: "#fff",
            badColored: "#ed0b0b"
          }
        strings = {
          "confirmMessage": ["", "Try again. Passwords don't match"]
        };
        if (password.value === password2.value && (password.value + password2.value) !== "") {
          password2.style.backgroundColor = colors["goodColor"];
          message.style.color = colors["goodColored"];
          message.innerHTML = strings["confirmMessage"][0];
        } else if (!(password2.value === "")) {
          password2.style.backgroundColor = colors["badColor"];
          message.style.color = colors["badColored"];
          message.innerHTML = strings["confirmMessage"][1];
        } else {
          message.innerHTML = "";
        }
      }
    </script>
    <script language="javascript" type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script language="javascript" type="text/javascript" src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
    <script language="javascript" type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script language="javascript" type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
    <script type="text/javascript" src="script.js"></script>
  </form>
</body>

</html>