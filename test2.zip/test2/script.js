  $(function() {
    function maskPhone() {
      var country = $('#country option:selected').val();
      switch (country) {
        case "ua":
          $("#phone").mask("+380(99) 999-99-99");
          break;
        case "us":
          $("#phone").mask("+1(99) 999-999-99");
          break;
        case "kz":
          $("#phone").mask("+77(99) 999-99-99");
          break;
        case "uz":
          $("#phone").mask("+998(99) 999-99-99");
          break;
        case "bg":
          $("#phone").mask("+359(99) 999-99-99");
          break;
        case "md":
          $("#phone").mask("+373(99) 999-999");
          break;
        case "pl":
          $("#phone").mask("+48(99) 999-99-99");
          break;
        case "sk":
          $("#phone").mask("+421(99) 999-99-99");
          break;
        case "az":
          $("#phone").mask("+994(99) 999-99-99");
          break;
        case "by":
          $("#phone").mask("+375(99) 999-99-99");
          break;
        case "cz":
          $("#phone").mask("+420(99) 999-99-99");
          break;
        case "ro":
          $("#phone").mask("+40(99) 999-99-99");
          break; 
        case "ge":
          $("#phone").mask("+995(99) 999-99-99");
          break;
        case "mx":
          $("#phone").mask("+52(99) 999-999-999");
          break;
        case "kh":
          $("#phone").mask("+855(99) 999-999");
          break;
        case "br":
          $("#phone").mask("+55(99) 999-999-99");
          break;
        case "ch":
          $("#phone").mask("+41(99) 999-99-99");
          break;
      }    
    }
    maskPhone();
    $('#country').change(function() {
      maskPhone();
    });
  });
