<!--SendMail-->
<?php
	if (isset($_POST)){
	
		$name=$_POST['name'];
		$lastname=$_POST['lastname'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$password=$_POST['password'];
		
		$result = mail('kirillkoshel0108@gmail.com', 'Повідомлення з сайту', $name."\n"$lastname."\n".$email."\n".$phone."\n".$password);
		if($result) {
			echo 'Дані відправлено на mail';
		}
		else {
			echo 'Вийшла помилка';
		}
	}
?>

<!--SendFile-->
<?php
	$data = array($name, $lastname, $email, $phone, $password);
	$str = implode(' ', $data);
	$h = fopen('quest_book.txt', 'a');
	fwrite($h, $str);
	echo 'Дані записано у файл quest_book.txt';
?>